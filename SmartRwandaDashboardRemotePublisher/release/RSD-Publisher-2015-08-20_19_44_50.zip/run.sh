java -jar RSD-Publisher.jar
